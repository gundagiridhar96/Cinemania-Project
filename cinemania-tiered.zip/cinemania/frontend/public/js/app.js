// ===== CINEMANIA - Main App JS =====
const API = 'http://localhost:5000/api';

// ===== AUTH STATE =====
const Auth = {
  getToken: () => localStorage.getItem('cm_token'),
  getUser: () => { try { return JSON.parse(localStorage.getItem('cm_user')); } catch { return null; } },
  setAuth: (token, user) => { localStorage.setItem('cm_token', token); localStorage.setItem('cm_user', JSON.stringify(user)); },
  clear: () => { localStorage.removeItem('cm_token'); localStorage.removeItem('cm_user'); },
  isLoggedIn: () => !!localStorage.getItem('cm_token'),
  isAdmin: () => { const u = Auth.getUser(); return u && u.role === 'admin'; }
};

// ===== API HELPER =====
async function apiFetch(path, options = {}) {
  const token = Auth.getToken();
  const headers = { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers };
  const res = await fetch(`${API}${path}`, { ...options, headers });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Request failed');
  return data;
}

// ===== TOAST =====
function toast(msg, type = 'info') {
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  let container = document.querySelector('.toast-container');
  if (!container) { container = document.createElement('div'); container.className = 'toast-container'; document.body.appendChild(container); }
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.innerHTML = `<span>${icons[type]}</span><span>${msg}</span>`;
  container.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(120%)'; el.style.transition = '0.4s'; setTimeout(() => el.remove(), 400); }, 3000);
}

// ===== NAVBAR =====
function renderNavbar() {
  const nav = document.getElementById('navbar');
  if (!nav) return;
  const user = Auth.getUser();
  const isLoggedIn = Auth.isLoggedIn();
  nav.innerHTML = `
    <a href="/" class="navbar-brand">CINE<span>MANIA</span></a>
    <ul class="navbar-nav">
      <li><a href="/" class="${location.pathname === '/' ? 'active' : ''}">Home</a></li>
      <li><a href="/browse.html" class="${location.pathname.includes('browse') ? 'active' : ''}">Browse</a></li>
      <li><a href="/plans.html" class="${location.pathname.includes('plans') ? 'active' : ''}">Plans</a></li>
      ${isLoggedIn ? `<li><a href="/watchlist.html" class="${location.pathname.includes('watchlist') ? 'active' : ''}">Watchlist</a></li>` : ''}
    </ul>
    <div class="navbar-actions">
      <button class="btn btn-ghost btn-sm" onclick="openSearch()" title="Search">🔍</button>
      ${isLoggedIn ? `
        <div class="user-menu">
          <div class="user-avatar" onclick="toggleDropdown()" title="${user?.name}">${user?.name?.[0]?.toUpperCase() || 'U'}</div>
          <div class="dropdown-menu" id="userDropdown">
            <a href="/profile.html" class="dropdown-item">👤 My Profile</a>
            <a href="/plans.html" class="dropdown-item">💎 Subscription</a>
            ${Auth.isAdmin() ? `<a href="/admin.html" class="dropdown-item">⚙️ Admin Panel</a>` : ''}
            <div class="dropdown-divider"></div>
            <button class="dropdown-item danger" onclick="logout()">🚪 Logout</button>
          </div>
        </div>` : `
        <button class="btn btn-outline btn-sm" onclick="openModal('loginModal')">Log In</button>
        <button class="btn btn-primary btn-sm" onclick="openModal('registerModal')">Sign Up</button>`}
    </div>`;
}

function toggleDropdown() {
  const dd = document.getElementById('userDropdown');
  if (dd) dd.classList.toggle('show');
}
document.addEventListener('click', e => {
  if (!e.target.closest('.user-menu')) {
    document.querySelectorAll('.dropdown-menu').forEach(d => d.classList.remove('show'));
  }
});

// ===== MODALS =====
function openModal(id) { document.getElementById(id)?.classList.add('show'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('show'); }
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) e.target.classList.remove('show');
});

// ===== SEARCH =====
function openSearch() { document.getElementById('searchOverlay')?.classList.add('show'); document.getElementById('searchInput')?.focus(); }
function closeSearch() { document.getElementById('searchOverlay')?.classList.remove('show'); }

let searchTimeout;
async function handleSearch(e) {
  const q = e.target.value.trim();
  const results = document.getElementById('searchResults');
  if (!results) return;
  if (!q) { results.innerHTML = ''; return; }
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(async () => {
    try {
      const data = await apiFetch(`/content?search=${encodeURIComponent(q)}`);
      if (!data.length) { results.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:2rem">No results found</p>'; return; }
      results.innerHTML = data.slice(0,8).map(c => `
        <div class="search-result-item" onclick="window.location='/browse.html?id=${c.id}';closeSearch()">
          <div class="search-result-icon">${getContentEmoji(c.genre)}</div>
          <div>
            <div style="font-weight:600;font-size:0.9rem">${c.title}</div>
            <div style="font-size:0.75rem;color:var(--text-muted)">${c.type} · ${c.release_year || 'N/A'} · ⭐ ${c.rating}</div>
          </div>
          ${!c.has_access ? `<span style="margin-left:auto;font-size:0.8rem;color:var(--accent-gold)">🔒</span>` : ''}
        </div>`).join('');
    } catch(err) { results.innerHTML = ''; }
  }, 300);
}

// ===== AUTH FORMS =====
async function handleLogin(e) {
  e.preventDefault();
  const btn = e.target.querySelector('.form-submit');
  const alertEl = document.getElementById('loginAlert');
  btn.textContent = 'Signing in...'; btn.disabled = true;
  try {
    const data = await apiFetch('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: document.getElementById('loginEmail').value, password: document.getElementById('loginPassword').value })
    });
    Auth.setAuth(data.token, data.user);
    closeModal('loginModal');
    toast('Welcome back, ' + data.user.name + '!', 'success');
    setTimeout(() => location.reload(), 500);
  } catch(err) {
    alertEl.innerHTML = `<div class="alert alert-error">⚠️ ${err.message}</div>`;
    btn.textContent = 'Log In'; btn.disabled = false;
  }
}

async function handleRegister(e) {
  e.preventDefault();
  const btn = e.target.querySelector('.form-submit');
  const alertEl = document.getElementById('registerAlert');
  btn.textContent = 'Creating account...'; btn.disabled = true;
  try {
    const data = await apiFetch('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name: document.getElementById('regName').value, email: document.getElementById('regEmail').value, password: document.getElementById('regPassword').value })
    });
    Auth.setAuth(data.token, data.user);
    closeModal('registerModal');
    toast('Account created! Welcome to CineMania 🎬', 'success');
    setTimeout(() => location.reload(), 500);
  } catch(err) {
    alertEl.innerHTML = `<div class="alert alert-error">⚠️ ${err.message}</div>`;
    btn.textContent = 'Create Account'; btn.disabled = false;
  }
}

function logout() {
  Auth.clear();
  toast('Logged out. See you soon!', 'info');
  setTimeout(() => location.href = '/', 500);
}

// ===== CONTENT HELPERS =====
const GENRE_EMOJIS = { action: '💥', crime: '🔫', 'sci-fi': '🚀', drama: '🎭', comedy: '😂', horror: '👻', thriller: '😱', romance: '❤️', animation: '🎨', documentary: '📹', history: '📜', adventure: '🗺️' };
function getContentEmoji(genre) {
  if (!genre) return '🎬';
  const g = genre.toLowerCase();
  for (const [key, emoji] of Object.entries(GENRE_EMOJIS)) { if (g.includes(key)) return emoji; }
  return '🎬';
}

function renderContentCard(item, inRow = true) {
  const emoji = getContentEmoji(item.genre);
  const hasAccess = item.has_access !== false;
  const isNew = item.is_new;
  const isTrending = item.is_trending;
  return `
    <div class="content-card ${inRow ? '' : 'grid-card'}" onclick="viewContent(${item.id})">
      <div class="card-poster">${emoji}</div>
      ${isNew ? '<span class="card-badge blue">NEW</span>' : isTrending ? '<span class="card-badge">HOT</span>' : ''}
      ${!hasAccess ? `<div class="card-lock"><div class="card-lock-icon">🔒</div><div>Upgrade to<br><b>${item.required_plan}</b></div></div>` : ''}
      <div class="card-overlay">
        <div class="card-title">${item.title}</div>
        <div class="card-meta">⭐ ${item.rating} · ${item.release_year || ''} · ${item.type}</div>
        <div class="card-actions">
          ${hasAccess ? `<button class="btn btn-primary btn-sm" onclick="watchContent(event,${item.id})">▶ Play</button>` : `<button class="btn btn-gold btn-sm" onclick="event.stopPropagation();window.location='/plans.html'">Upgrade</button>`}
          ${Auth.isLoggedIn() ? `<button class="btn btn-ghost btn-sm" onclick="addWatchlist(event,${item.id})">+ List</button>` : ''}
        </div>
      </div>
    </div>`;
}

function viewContent(id) { window.location = `/browse.html?id=${id}`; }

async function watchContent(e, id) {
  e.stopPropagation();
  if (!Auth.isLoggedIn()) { toast('Please log in to watch', 'info'); openModal('loginModal'); return; }
  try {
    const data = await apiFetch(`/content/${id}/watch`, { method: 'POST' });
    toast('Opening player... 🎬', 'success');
    // In a real app, this would open a video player
    setTimeout(() => alert(`🎬 Now Playing!\n\nVideo URL: ${data.video_url}\n\n(In production, this would open a video player)`), 200);
  } catch(err) {
    if (err.message.includes('Upgrade')) { toast(err.message, 'info'); setTimeout(() => window.location = '/plans.html', 1000); }
    else { toast(err.message, 'error'); }
  }
}

async function addWatchlist(e, id) {
  e.stopPropagation();
  if (!Auth.isLoggedIn()) { toast('Please log in first', 'info'); return; }
  try {
    await apiFetch(`/content/${id}/watchlist`, { method: 'POST' });
    toast('Added to watchlist!', 'success');
  } catch(err) { toast(err.message, 'error'); }
}

// ===== SUBSCRIPTION =====
async function subscribeToPlan(planId, planName) {
  if (!Auth.isLoggedIn()) { toast('Please log in to subscribe', 'info'); openModal('loginModal'); return; }
  if (!confirm(`Subscribe to ${planName} plan? This will replace your current subscription.`)) return;
  try {
    const data = await apiFetch('/subscriptions/subscribe', { method: 'POST', body: JSON.stringify({ plan_id: planId }) });
    toast(data.message, 'success');
    setTimeout(() => window.location = '/profile.html', 1000);
  } catch(err) { toast(err.message, 'error'); }
}

// ===== NAVBAR SCROLL =====
window.addEventListener('scroll', () => {
  const nav = document.getElementById('navbar');
  if (nav) nav.classList.toggle('scrolled', window.scrollY > 50);
});

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  renderNavbar();
  // Keyboard shortcuts
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeSearch(); document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('show')); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); openSearch(); }
  });
});
